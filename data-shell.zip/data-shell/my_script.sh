#1/bin/bash
head -n 10 $@

